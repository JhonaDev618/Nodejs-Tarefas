import tarefaRepository from "../repositories/tarefaRepository.js";

function buscarTarefas (){
    return tarefaRepository.buscarTarefas()
}

function buscarTarefa (id){
    return  tarefaRepository.buscarTarefa(id)
}

function criarTarefa(titulo){
  return tarefaRepository.criarTarefa(titulo)

}

function alterarTarefa(tarefaAtualizada){
    return tarefaRepository.alterarTarefa(tarefaAtualizada)
}


function excluirTarefa(id){
    return tarefaRepository.excluirTarefa(id)
}

export default {
    buscarTarefas,
    buscarTarefa,
    criarTarefa,
    alterarTarefa,
    excluirTarefa

}