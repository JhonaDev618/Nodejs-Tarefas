import express from "express"
import tarefaController from '../controllers/tarefaController.js'
const router = express.Router();

router.use(express.json()) // necessário paa trabalhar com json

router.get('/', tarefaController.buscarTarefas)
router.get('/:id', tarefaController.buscarTarefa)
router.post('/', tarefaController.criarTarefa)
router.put('/:id', tarefaController.alterarTarefa)
router.delete ('/:id', tarefaController.excluirTarefa)

export default router