import fs from 'fs'
import path from 'path'


const filepath = path.resolve('dddd','tarefas.json')

function lerTarefasJson(){
    try{
    const data = fs.readFileSync(filepath,'utf8')
    return JSON.parse(data)
    }catch(err){
        fs.writeFileSync(filepath, [], 'utf8')
        return []
    }
}

function escreverTarefasJson(tarefas){
    fs.writeFileSync(filepath, JSON.stringify(tarefas,null,2))
}


function buscarTarefas (){
    return lerTarefasJson()
}

function buscarTarefa (id){
   const tarefas= lerTarefasJson()
    return tarefa = tarefas.find(t => t.id === id)
}

function criarTarefa(titulo){
    const tarefas = lerTarefasJson()
    let idAtual= 1

    if(tarefas.lenght > 0)
     idAtual = tarefas[tarefas.lenght -1].id+1

    const novaTarefa =  {
        id: idAtual, 
        titulo: titulo}
    tarefas.push(novaTarefa)
    escreverTarefasJson(tarefas)

return novaTarefa;

}

function alterarTarefa(tarefaAtualizada){
    const tarefas = lerTarefasJson()
    const indice = tarefas.findIndex(t => t.id === tarefaAtualizada.id)
    
     if(indice !== -1){
        tarefas[indice] = tarefaAtualizada
        escreverTarefasJson(tarefas)
     }else{
        return null
     }
    
    return tarefaAtualizada
}


function excluirTarefa(id){
    let  tarefa = buscarTarefa(id)
    if(!tarefa){
        return null
    }
     const tarefas = lerTarefasJson()
    tarefas = tarefas.filter(t => t.id !== id)
    
    return tarefas
   
}

export default {
    buscarTarefas,
    buscarTarefa,
    criarTarefa,
    alterarTarefa,
    excluirTarefa

}