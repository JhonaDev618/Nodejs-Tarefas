import tarefaService from "../service/tarefaService.js"


function buscarTarefas (req,res){
    res.json(tarefaService.buscarTarefas())
}

function buscarTarefa (req,res) {
    const id = parseInt(req.params.id)
    const tarefa = tarefaService.buscarTarefa(id)
    if (!tarefa){
        return res.status(400).json({menssagem: "Tarefa não encontrada"})
     }
     res.json(tarefa)
}
    

function criarTarefa (req, res) { 
    
const titulo = req.body.titulo
  
    if (!titulo){
       return res.status(400).json({menssagem: "Titulo Obrigatório"})
    }
     
    const novaTarefa= tarefaService.criarTarefa(titulo)

     res.status(201).json(novaTarefa)
}


function alterarTarefa (req,res) {
    const id = parseInt(req.params.id)
    const titulo = req.body.titulo
    const tarefaAtualizada = {
        id: id,
        titulo: titulo
    }
    
    const tarefa = tarefaService.alterarTarefa(tarefaAtualizada)

    if (!tarefa){
        return res.status(400).json({menssagem: "Tarefa não encontrada"})
     }

    if(titulo){
        tarefa.titulo = titulo
         
    }
    
    res.json(tarefa)
}


function excluirTarefa (req,res) {
    const id = parseInt(req.params.id)
    const tarefaExcluida = tarefaService.excluirTarefa(id)
    if (!tarefaExcluida){
        return res.status(400).json({menssagem: "Tarefa não encontrada"})
     }
     res.status(204).send()
}


export default{
    buscarTarefas,
    buscarTarefa,
    criarTarefa,
    alterarTarefa,
    excluirTarefa
}