 import express, { Router } from 'express'
 import router from './routes/tarefaRoutes.js'
 const app = express()


 const PORT = 3333

 app.use('/tarefas', router)


app.listen(PORT, () =>{
    console.log('Servidor rodando na porta 3333')
})


